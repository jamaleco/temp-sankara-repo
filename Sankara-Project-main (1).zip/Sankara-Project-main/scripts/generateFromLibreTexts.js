import fetch from "node-fetch";
import { JSDOM } from "jsdom";
import fs from "fs";
import path from "path";
import slugify from "slugify";

const BOOK_URL =
  "https://chem.libretexts.org/Bookshelves/Introductory_Chemistry/Introductory_Chemistry_(LibreTexts)";

const SUBJECT_ID = "chemistry";
const OUTPUT_DIR = path.resolve("public/textbooks", SUBJECT_ID);

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

async function getHTML(url) {
  const res = await fetch(url);
  return res.text();
}

function extractChapterLinks(dom) {
  return [...dom.window.document.querySelectorAll("a")]
    .map(a => a.href)
    .filter(h =>
      h &&
      h.includes("/Bookshelves/") &&
      !h.includes("#")
    )
    .filter((v, i, a) => a.indexOf(v) === i);
}

async function main() {
  ensureDir(OUTPUT_DIR);

  const bookHTML = await getHTML(BOOK_URL);
  const bookDOM = new JSDOM(bookHTML);

  const title =
    bookDOM.window.document.querySelector("h1")?.textContent.trim() ??
    "LibreTexts Book";

  const chapterLinks = extractChapterLinks(bookDOM);

  console.log(`Found ${chapterLinks.length} chapters`);

  const chapters = [];

  for (let i = 0; i < chapterLinks.length; i++) {
    const url = chapterLinks[i];
    console.log(`Fetching ${i + 1}/${chapterLinks.length}`);

    const html = await getHTML(url);
    const dom = new JSDOM(html);

    const chapterTitle =
      dom.window.document.querySelector("h1")?.textContent.trim() ??
      `Chapter ${i + 1}`;

    const content =
      dom.window.document.querySelector("#content")?.textContent.trim() ??
      "";

    if (content.length < 200) continue;

    chapters.push({
      id: `ch${chapters.length + 1}`,
      title: chapterTitle,
      content
    });
  }

  const bookId = slugify(title, { lower: true, strict: true });

  const bookData = {
    meta: {
      title,
      source: "LibreTexts",
      license: "CC BY 4.0",
      originalUrl: BOOK_URL
    },
    chapters
  };

  fs.writeFileSync(
    path.join(OUTPUT_DIR, `${bookId}.json`),
    JSON.stringify(bookData, null, 2)
  );

  const indexPath = path.resolve("public/textbooks/index.json");

  const index = fs.existsSync(indexPath)
    ? JSON.parse(fs.readFileSync(indexPath))
    : { subjects: [] };

  let subject = index.subjects.find(s => s.id === SUBJECT_ID);
  if (!subject) {
    subject = { id: SUBJECT_ID, name: "Chemistry", books: [] };
    index.subjects.push(subject);
  }

  subject.books.push({
    id: bookId,
    title,
    file: `/textbooks/${SUBJECT_ID}/${bookId}.json`
  });

  fs.writeFileSync(indexPath, JSON.stringify(index, null, 2));

  console.log("libretexts good import yay");
}

main();
