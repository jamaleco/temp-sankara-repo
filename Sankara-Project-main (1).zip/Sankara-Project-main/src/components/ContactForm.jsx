import React from "react";
import Footer from "./Footer";

export default function ContactUsPanel() {
  return (
    <div className="w-full h-full flex flex-col overflow-y-auto">

      {/* main contact section */}
      <div className="flex justify-center items-start pt-10 flex-1">
        <div className="bg-white p-6 rounded-lg shadow-md w-[380px] mb-10">
          <h1 className="text-center text-4xl font-bold mb-1">feel free to</h1>
          <p className="text-center text-gray-600 mb-6">reach out</p>

          <form className="flex flex-col gap-4">
            <div>
              <label className="block text-sm mb-1">Name</label>
              <input className="w-full border rounded-md p-2" placeholder="Value" />
            </div>

            <div>
              <label className="block text-sm mb-1">Surname</label>
              <input className="w-full border rounded-md p-2" placeholder="Value" />
            </div>

            <div>
              <label className="block text-sm mb-1">Email</label>
              <input className="w-full border rounded-md p-2" placeholder="Value" />
            </div>

            <div>
              <label className="block text-sm mb-1">Message</label>
              <textarea className="w-full border rounded-md p-2" placeholder="Value" rows="4" />
            </div>

            <button
              type="submit"
              className="w-full bg-black text-white py-2 rounded-md mt-2"
            >
              Submit
            </button>
          </form>
        </div>
      </div>

      {/* footer always at bottom */}
      <Footer />
    </div>
  );
}
