import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, X } from "lucide-react";

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { from: "bot", text: "assistant info" },
    { from: "bot", text: "here to help!" },
  ]);
  const [input, setInput] = useState("");
  const widgetRef = useRef(null);

  // Size state: width and top position (bottom fixed)
  const [size, setSize] = useState({ width: 280, top: 100 });

  const fabHeight = 56; // approximate FAB height
  const bottomOffset = 16 + fabHeight + 4; // space above FAB

  const handleMouseDownLeft = (e) => {
    const startX = e.clientX;
    const startWidth = size.width;

    const move = (e) => {
      const newWidth = startWidth + (startX - e.clientX);
      if (newWidth > 200 && newWidth < 600) {
        setSize((s) => ({ ...s, width: newWidth }));
      }
    };

    const up = () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  const handleMouseDownTop = (e) => {
    const startY = e.clientY;
    const startTop = size.top;

    const move = (e) => {
      const newTop = startTop + (e.clientY - startY);
      if (newTop >= 10 && newTop < window.innerHeight - 150 - bottomOffset) {
        setSize((s) => ({ ...s, top: newTop }));
      }
    };

    const up = () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  const mergedMessages = [];
  messages.forEach((msg) => {
    const last = mergedMessages[mergedMessages.length - 1];
    if (last && last.from === msg.from) last.text += `\n${msg.text}`;
    else mergedMessages.push({ ...msg });
  });

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(!open)}
        className="fixed bottom-4 right-4 bg-black text-white p-3 rounded-full shadow-xl z-50"
      >
        {open ? <X size={22} /> : <MessageSquare size={22} />}
      </motion.button>

      <AnimatePresence>
        {open && (
              <motion.div
      ref={widgetRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ type: "spring", stiffness: 200, damping: 22 }}
      style={{
        width: size.width,
        top: size.top,
        right: 16,
        bottom: bottomOffset, // keeps bottom above FAB
      }}
      className="fixed rounded-2xl shadow-2xl bg-white/70 backdrop-blur-xl border border-white/40 flex flex-col overflow-hidden z-50"
    >
      <div
        onMouseDown={handleMouseDownTop}
        className="absolute top-0 left-0 right-0 h-2 cursor-n-resize z-10"
      />
      <div
        onMouseDown={handleMouseDownLeft}
        className="absolute top-0 left-0 w-2 bottom-0 cursor-w-resize z-10"
      />

      <div className="px-4 py-3 border-b border-white/40 flex items-center justify-between bg-white/30 backdrop-blur-md select-none">
        <h2 className="font-semibold text-gray-800">Assistant</h2>
        <button onClick={() => setOpen(false)} className="text-gray-700">
          <X size={22} />
        </button>
      </div>

            <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2 text-sm">
              {mergedMessages.map((m, i) => (
                <div
                  key={i}
                  className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}
                >
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`px-3 py-2 max-w-[200px] rounded-lg whitespace-pre-line shadow-sm backdrop-blur-md ${
                      m.from === "user"
                        ? "bg-purple-100 text-purple-700 text-right"
                        : "bg-gray-100 text-left"
                    }`}
                  >
                    <div className="text-xs font-semibold mb-1">
                      {m.from === "user" ? "You" : "Assistant"}
                    </div>
                    {m.text}
                  </motion.div>
                </div>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!input.trim()) return;
                setMessages((m) => [...m, { from: "user", text: input }]);
                setInput("");
              }}
              className="px-4 py-3 border-t border-white/40 bg-white/30 backdrop-blur-md"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-0 focus:border-gray-400 outline-none text-sm"
                placeholder="Ask a question..."
              />
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
