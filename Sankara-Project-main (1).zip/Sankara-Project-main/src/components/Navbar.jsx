import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Menu, X } from "lucide-react";

export default function Navbar({ activeTab, setActiveTab }) {
  const tabs = [
    { id: "home", label: "home" },
    { id: "textbook", label: "textbooks" },
    { id: "settings", label: "settings" },
    { id: "help", label: "help and resources" },
    { id: "about", label: "about us" },
    { id: "contact", label: "contact us" },
  ];

  const [currentTime, setCurrentTime] = useState("");
  const [showClock, setShowClock] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const date = now.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }).toLowerCase();
      const time = now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", second: "2-digit" });
      setCurrentTime(`${date} • ${time}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-[#E5E5E5] shadow-sm px-4 md:px-6">
      <div className="h-14 flex items-center justify-between relative">

        {/* Left - Clock */}
        <div className="flex items-center relative">
          <div className={`flex items-center gap-2 transition-all duration-300 ${showClock ? "translate-x-0 opacity-100" : "-translate-x-full opacity-0"}`}>
            <div className="text-[13px] text-gray-700 font-medium tracking-wide">{currentTime}</div>
            <button onClick={() => setShowClock(false)} className="p-1 hover:bg-gray-200 rounded">
              <ChevronLeft size={14} />
            </button>
          </div>
          {!showClock && (
            <button onClick={() => setShowClock(true)} className="p-1 hover:bg-gray-200 rounded absolute left-0">
              <ChevronRight size={14} />
            </button>
          )}
        </div>

        {/* Center - Tabs */}
        <div className="flex-1 flex justify-center overflow-hidden">
          <div className="hidden md:flex gap-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`text-[13px] lowercase tracking-wide pb-[2px] transition-all ${activeTab === tab.id ? "text-black border-b-[2px] border-black" : "text-gray-500 hover:text-gray-700 border-b-[2px] border-transparent"}`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Right - Profile + Hamburger */}
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 cursor-pointer">
            <img
              src="/images/defaultpfp.jpg"
              alt="User Avatar"
              className="w-8 h-8 rounded-full border border-gray-300"
            />
            <span className="text-sm text-gray-700">admin</span>
          </div>

          <button className="md:hidden p-1 hover:bg-gray-200 rounded" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden flex flex-col gap-2 px-4 py-2 bg-[#E5E5E5] border-t border-gray-300 transition-all duration-300">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); setMenuOpen(false); }}
              className={`text-[13px] lowercase tracking-wide py-2 transition-all ${activeTab === tab.id ? "text-black font-medium" : "text-gray-600 hover:text-gray-800"}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
