import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

import {
  loadSettings,
  saveSettings,
  applySettings,
  DEFAULT
} from "../lib/settings";

const pageVariants = {
  initial: (direction) => ({
    x: direction > 0 ? 40 : -40,
    opacity: 0
  }),

  animate: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.25 }
  },

  exit: (direction) => ({
    x: direction > 0 ? -40 : 40,
    opacity: 0,
    transition: { duration: 0.2 }
  })
};

/* ---------------- UI components ---------------- */

function Row({ label, desc, right }) {
  return (
    <div className="flex items-center justify-between py-5">
      <div className="pr-6">

        <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
          {label}
        </div>

        {desc && (
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
            {desc}
          </div>
        )}

      </div>

      <div>{right}</div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section className="mt-10">

      <h3 className="text-xs uppercase tracking-wider text-gray-400 mb-2">
        {title}
      </h3>

      <div className="
        bg-white dark:bg-gray-800
        rounded-lg
        divide-y divide-gray-200 dark:divide-gray-200
        shadow-sm
        px-6
      ">
        {children}
      </div>

    </section>
  );
}

function Select({ value, options, onChange }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="
        text-sm
        bg-gray-100 dark:bg-gray-700
        text-gray-900 dark:text-white
        px-3 py-1.5
        rounded-md
      "
    >
      {options.map((o) => (
        <option key={o}>{o}</option>
      ))}
    </select>
  );
}

/* ---------------- main panel ---------------- */

export default function SettingsPanel() {

  const [settings, setSettings] = useState(loadSettings());

  function update(key, value) {

    const newSettings = {
      ...settings,
      [key]: value
    };

    setSettings(newSettings);

    saveSettings(newSettings);

    applySettings(newSettings);
  }

  function resetSettings() {

    setSettings(DEFAULT);

    saveSettings(DEFAULT);

    applySettings(DEFAULT);
  }

  useEffect(() => {
    applySettings(settings);
  }, []);

  return (
    <div className="w-full min-h-screen bg-gray-50 dark:bg-gray-900">

      <AnimatePresence>

        <motion.div
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
        >

          <div className="w-full max-w-3xl px-6 pb-32">

            <Section title="important">

              <Row
                label="font size"
                desc="recommended – medium"
                right={
                  <Select
                    value={settings.fontSize}
                    options={["small", "medium", "large"]}
                    onChange={(v) => update("fontSize", v)}
                  />
                }
              />

            </Section>

            <Section title="appearance">

              <Row
                label="theme"
                desc="light, dark, or system"
                right={
                  <Select
                    value={settings.theme}
                    options={["light", "dark", "system"]}
                    onChange={(v) => update("theme", v)}
                  />
                }
              />

              <Row
                label="accent colour"
                desc="customize highlights"
                right={
                  <input
                    type="color"
                    value={settings.accent}
                    onChange={(e) => update("accent", e.target.value)}
                  />
                }
              />

              <Row
                label="reset settings"
                desc="restore defaults"
                right={
                  <button
                    onClick={resetSettings}
                    className="text-red-500 hover:text-red-600 text-sm"
                  >
                    reset
                  </button>
                }
              />

            </Section>

          </div>

        </motion.div>

      </AnimatePresence>

    </div>
  );
}