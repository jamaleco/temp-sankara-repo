import React from "react";

export default function Footer() {
    return (
        <footer className="bg-white border-t mt-16">
            <div className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-3 gap-8 text-sm">
                <div>
                    <h3 className="font-semibold mb-2">More About Us</h3>
                    <ul><li>asdf</li><li>asdf</li><li>asdf</li></ul>
                </div>
                <div>
                    <h3 className="font-semibold mb-2">Updates</h3>
                    <ul><li>asdf</li><li>asdf</li></ul>
                </div>
                <div>
                    <h3 className="font-semibold mb-2">Textbook Resources</h3>
                    <ul><li>aasdfsa</li><li>basdf</li></ul>
                </div>
            </div>
        </footer>
    );
}
