export default function HelpResourcesPanel() {
  return <div>Help & Resources Panel</div>;
}
