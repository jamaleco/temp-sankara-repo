import React, { useState } from "react";

export default function Toggle() {
    const [on, setOn] = useState(false);

    return (
        <button 
        onClick={() => setOn(!on)}
        className={`w-12 h-7 rounded-full p-1 transition ${on ? "bg-gray-900" : "bg-gray-300"}`}
        >
        <div className={`w-5 h-5 bg-white rounded-full transition ${on ? "translate-x-5" : ""}`} />
        </button>
    );
}
