export default function AboutUsPanel() {
  return <div>About Us Panel</div>;
}
