import { useEffect, useState } from "react";

export default function TextbookPanel({ onHighlight, openBook }) {
  const [index, setIndex] = useState(null);
  const [book, setBook] = useState(null);
  const [activeChapter, setActiveChapter] = useState(null);
  const [selection, setSelection] = useState("");

  useEffect(() => {
    fetch("/textbooks/index.json")
      .then((res) => res.text())
      .then((text) => {
        if (!text) throw new Error("Empty index file");
        const data = JSON.parse(text);
        setIndex(data.subjects ? data : { subjects: [] });
      })
      .catch((err) => {
        console.error("Failed to load index.json:", err);
        setIndex({ subjects: [] });
      });
  }, []);

  useEffect(() => {
    const handleSelection = () => setSelection(window.getSelection().toString().trim());
    document.addEventListener("selectionchange", handleSelection);
    return () => document.removeEventListener("selectionchange", handleSelection);
  }, []);

  const handleAskAI = () => {
    if (!selection) return;
    onHighlight?.(selection);
    setSelection("");
    const sel = window.getSelection();
    if (sel) sel.removeAllRanges();
  };

  const loadBook = (path) => {
    fetch(path)
      .then((res) => res.text())
      .then((text) => {
        if (!text) throw new Error("Empty book file");
        const data = JSON.parse(text);
        if (!data.chapters || !Array.isArray(data.chapters) || data.chapters.length === 0)
          throw new Error("Book has no chapters");
        setBook(data);
        setActiveChapter(data.chapters[0]);
        openBook?.(data);
      })
      .catch((err) => alert("Failed to load book: " + err.message));
  };

  if (!index) return <div className="flex items-center justify-center h-full text-gray-500">Loading textbooks…</div>;

  if (!book) {
    return (
      <div className="max-w-3xl mx-auto px-10 py-8">
        <h1 className="text-2xl font-semibold mb-6">Textbooks</h1>
        {index.subjects.map((subject) => (
          <div key={subject.id || subject.name} className="mb-6">
            <h2 className="text-lg font-medium mb-2">{subject.name}</h2>
            <div className="space-y-2">
              {(subject.books || []).map((b) => (
                <button
                  key={b.id || b.title}
                  onClick={() => loadBook(b.path)}
                  className="block w-full text-left px-4 py-3 rounded-lg bg-white shadow-sm hover:bg-gray-100"
                >
                  <div className="font-medium text-gray-900">{b.title}</div>
                  <div className="text-xs text-gray-500">{b.source}</div>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex h-full">
      <aside className="w-64 bg-white border-r overflow-y-auto">
        <div className="p-4 border-b">
          <button
            onClick={() => { setBook(null); setActiveChapter(null); }}
            className="text-xs text-gray-500 hover:text-gray-700 mb-2"
          >
            ← Back to library
          </button>
          <h2 className="text-sm font-semibold">{book.meta?.title || "Untitled Book"}</h2>
          <p className="text-xs text-gray-500 mt-1">
            {book.meta?.subject || "Unknown"} • {book.meta?.source || "Unknown"}
          </p>
        </div>
        <div className="p-2">
          {(book.chapters || []).map((ch) => (
            <button
              key={ch.id || ch.title}
              onClick={() => setActiveChapter(ch)}
              className={`w-full text-left px-3 py-2 rounded-md text-sm mb-1 ${activeChapter?.id === ch.id ? "bg-gray-200 text-gray-900" : "hover:bg-gray-100 text-gray-600"}`}
            >
              {ch.title}
            </button>
          ))}
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto px-10 py-8">
        <h1 className="text-2xl font-semibold mb-4">{activeChapter?.title || "No Chapter Selected"}</h1>
        <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-line max-w-3xl">
          {activeChapter?.content || "No content available."}
        </div>
        {selection && (
          <button onClick={handleAskAI} className="mt-6 text-sm text-purple-600 hover:underline">
            Ask AI about “{selection.length > 60 ? selection.slice(0, 60) + "…" : selection}”
          </button>
        )}
        <div className="mt-10 text-xs text-gray-400">
          Source: {book.meta?.source || "Unknown"} • License: {book.meta?.license || "Unknown"}
        </div>
      </main>
    </div>
  );
}
