import React, { useState, useEffect } from "react";
import { Star } from "lucide-react";
import { motion } from "framer-motion";

export default function HomePanel({ onHighlight, book }) {
  if (book) {
    return (
      <div className="h-full overflow-y-auto px-10 py-8">
        <h1 className="text-2xl font-semibold mb-6">
          {book.meta.title}
        </h1>

        {book.chapters.map(ch => (
          <div key={ch.id} className="mb-10">
            <h2 className="text-lg font-medium mb-2">
              {ch.title}
            </h2>

            <div className="text-sm text-gray-700 whitespace-pre-line">
              {ch.content}
            </div>
          </div>
        ))}
      </div>
    );
  }

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeStars, setActiveStars] = useState(() => {
    const saved = localStorage.getItem("featureStars");
    return saved ? JSON.parse(saved) : {};
  });

  const features = [
    "Offline AI Tutor",
    "Preloaded Curriculums",
    "Lightweight Design",
    "Optional Teacher Dashboard",
    "Multilingual and Localised Support",
    "Community Mode",
  ];

  const toggleStar = (text) => {
    const updated = { ...activeStars, [text]: !activeStars[text] };
    setActiveStars(updated);
    localStorage.setItem("featureStars", JSON.stringify(updated));
  };

  return (
    <div className="w-full h-full flex flex-col px-10 py-6 text-gray-800 relative">
      <div
        className="absolute left-0 top-1/2 -translate-y-1/2 flex items-center"
        onMouseLeave={() => setSidebarOpen(false)}
      >
        <motion.div
          initial={{ x: -180, opacity: 0 }}
          animate={{
            x: sidebarOpen ? 0 : -180,
            opacity: sidebarOpen ? 1 : 0,
          }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="bg-white shadow-lg rounded-xl p-4 pointer-events-auto z-50"
        >
          {features.map((f) => (
            <Feature
              key={f}
              text={f}
              active={!!activeStars[f]}
              onClick={() => toggleStar(f)}
            />
          ))}
        </motion.div>

        <div
          onMouseEnter={() => setSidebarOpen(true)}
          className="w-40 h-64 absolute left-0 top-0 z-40"
        />
      </div>

      <div className="flex-1 flex flex-col items-center py-10 overflow-y-auto">
        <FlashcardScroll onHighlight={onHighlight} />
      </div>
    </div>
  );
}

function Feature({ text, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 mb-3 cursor-pointer transition-all"
    >
      <Star
        size={16}
        className={`${
          active ? "text-yellow-500 fill-yellow-500" : "text-gray-400"
        } transition-transform duration-200 ${active ? "scale-110" : "scale-100"}`}
      />
      <span className="text-sm">{text}</span>
    </button>
  );
}

/* ------------------- FLASHCARDS ------------------- */
function FlashcardScroll({ onHighlight }) {
  const cards = [
    {
      top: "Excitavit hic ardor milites per municipia plurima, quae isdem conterminant, dispositos et castella, sed quisque serpentes latius pro viribus repellere moliens, nunc globis confertos, aliquotiens et dispersos multitudine superabatur ingenti, quae nata et educata inter editos recurvosque ambitus montium eos ut loca plana persultat et mollia, missilibus obvios eminus lacessens et ululatu truci perterrens.\n\nEo adducta re per Isauriam, rege Persarum bellis finitimis inligato repellenteque a conlimitiis suis ferocissimas gentes, quae mente quadam versabili hostiliter eum saepe incessunt et in nos arma moventem aliquotiens iuvant, Nohodares quidam nomine e numero optimatum, incursare Mesopotamiam quotiens copia dederit ordinatus, explorabat nostra sollicite, si repperisset usquam locum vi subita perrupturus.\n\nVita est illis semper in fuga uxoresque mercenariae conductae ad tempus ex pacto atque, ut sit species matrimonii, dotis nomine futura coniunx hastam et tabernaculum offert marito, post statum diem si id elegerit discessura, et incredibile est quo ardore apud eos in venerem uterque solvitur sexus.",
      q: "question 1",
      a: "answer",
      bottom: "tap the card to flip it • scroll to continue",
    },
    {
      top: "Quam quidem partem accusationis admiratus sum et moleste tuli potissimum esse Atratino datam. Neque enim decebat neque aetas illa postulabat neque, id quod animadvertere poteratis, pudor patiebatur optimi adulescentis in tali illum oratione versari. Vellem aliquis ex vobis robustioribus hunc male dicendi locum suscepisset; aliquanto liberius et fortius et magis more nostro refutaremus istam male dicendi licentiam. Tecum, Atratine, agam lenius, quod et pudor tuus moderatur orationi meae et meum erga te parentemque tuum beneficium tueri debeo.\n\nPost haec indumentum regale quaerebatur et ministris fucandae purpurae tortis confessisque pectoralem tuniculam sine manicis textam, Maras nomine quidam inductus est ut appellant Christiani diaconus, cuius prolatae litterae scriptae Graeco sermone ad Tyrii textrini praepositum celerari speciem perurgebant quam autem non indicabant denique etiam idem ad usque discrimen vitae vexatus nihil fateri conpulsus est.\n\nEt Epigonus quidem amictu tenus philosophus, ut apparuit, prece frustra temptata, sulcatis lateribus mortisque metu admoto turpi confessione cogitatorum socium, quae nulla erant, fuisse firmavit cum nec vidisset quicquam nec audisset penitus expers forensium rerum; Eusebius vero obiecta fidentius negans, suspensus in eodem gradu constantiae stetit latrocinium illud esse, non iudicium clamans.",
      q: "question 2",
      a: "answer",
      bottom: "wild, right? scroll for more",
    },
    {
      top: "Huic Arabia est conserta, ex alio latere Nabataeis contigua; opima varietate conmerciorum castrisque oppleta validis et castellis, quae ad repellendos gentium vicinarum excursus sollicitudo pervigil veterum per oportunos saltus erexit et cautos. haec quoque civitates habet inter oppida quaedam ingentes Bostram et Gerasam atque Philadelphiam murorum firmitate cautissimas. hanc provinciae inposito nomine rectoreque adtributo obtemperare legibus nostris Traianus conpulit imperator incolarum tumore saepe contunso cum glorioso marte Mediam urgeret et Parthos.\n\nNec piget dicere avide magis hanc insulam populum Romanum invasisse quam iuste. Ptolomaeo enim rege foederato nobis et socio ob aerarii nostri angustias iusso sine ulla culpa proscribi ideoque hausto veneno voluntaria morte deleto et tributaria facta est et velut hostiles eius exuviae classi inpositae in urbem advectae sunt per Catonem, nunc repetetur ordo gestorum.\n\nNisi mihi Phaedrum, inquam, tu mentitum aut Zenonem putas, quorum utrumque audivi, cum mihi nihil sane praeter sedulitatem probarent, omnes mihi Epicuri sententiae satis notae sunt. atque eos, quos nominavi, cum Attico nostro frequenter audivi, cum miraretur ille quidem utrumque, Phaedrum autem etiam amaret, cotidieque inter nos ea, quae audiebamus, conferebamus, neque erat umquam controversia, quid ego intellegerem, sed quid probarem.",
      q: "question 3",
      a: "answer",
      bottom: "you reached the end!",
    },
  ];

  return (
    <div className="flex flex-col gap-6 w-full items-center">
      {cards.map((card, i) => (
        <SectionCard key={i} data={card} onHighlight={onHighlight} />
      ))}
    </div>
  );
}

function SectionCard({ data, onHighlight }) {
  const [selection, setSelection] = useState("");

  useEffect(() => {
    const handleSelectionChange = () => {
      const selectedText = window.getSelection().toString().trim();
      setSelection(selectedText);
    };

    document.addEventListener("selectionchange", handleSelectionChange);
    return () => document.removeEventListener("selectionchange", handleSelectionChange);
  }, []);

  const handleAskAI = () => {
    if (!selection) return;

    onHighlight(selection);

    setSelection("");

    const sel = window.getSelection();
    if (sel) sel.removeAllRanges();
  };

  return (
    <div className="w-full flex flex-col items-center">
      <div className="text-[13px] text-gray-500 tracking-wide whitespace-pre-line">
        {data.top}
      </div>

      <div className="relative w-[420px] h-[260px]">
        <div className="absolute inset-0 rounded-3xl bg-[#ece8ff] opacity-40" />
        <div className="absolute inset-0 top-2 left-2 rounded-3xl bg-[#f7f3ff] opacity-60" />
        <FlipCard question={data.q} answer={data.a} />
      </div>

      {selection && (
        <button
          onClick={handleAskAI}
          className="mt-3 text-sm text-purple-600 hover:underline"
        >
          Ask AI about "{selection.length > 50 ? selection.slice(0, 50) + "..." : selection}"
        </button>
      )}

      <div className="text-[13px] text-gray-500 tracking-wide mt-2 select-none">
        {data.bottom}
      </div>
    </div>
  );
}

function FlipCard({ question, answer }) {
  const [flipped, setFlipped] = useState(false);

  const handleFlip = () => {
    const selectedText = window.getSelection().toString().trim();
    // only flip if no text is selected
    if (!selectedText) setFlipped((f) => !f);
  };

  return (
    <div
      onClick={handleFlip}
      className="w-full h-full cursor-pointer"
      style={{ perspective: 1000 }}
    >
      <motion.div
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.6 }}
        className="relative w-full h-full"
        style={{ transformStyle: "preserve-3d" }}
      >
        <div
          className="absolute inset-0 bg-white rounded-3xl shadow-xl flex items-center justify-center px-8"
          style={{ backfaceVisibility: "hidden" }}
        >
          <p className="text-lg font-medium text-gray-700">{question}</p>
        </div>

        <div
          className="absolute inset-0 bg-white rounded-3xl shadow-xl flex items-center justify-center px-8"
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
        >
          <p className="text-lg font-medium text-gray-700">{answer}</p>
        </div>
      </motion.div>
    </div>
  );
}
