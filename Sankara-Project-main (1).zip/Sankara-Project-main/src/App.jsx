import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

import Navbar from "./components/Navbar";
import ChatWidget from "./components/ChatWidget";
import HomePanel from "./components/HomePanel";
import TextbookPanel from "./components/TextbookPanel";
import SettingsPanel from "./components/SettingsPanel";

const tabOrder = ["home", "textbook", "settings", "help", "about", "contact"];

export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [prevTab, setPrevTab] = useState("home");
  const [selectedBook, setSelectedBook] = useState(null);
  const [highlightedText, setHighlightedText] = useState("");
  const [openChat, setOpenChat] = useState(false);

  function switchTab(tab) {
    setPrevTab(activeTab);
    setActiveTab(tab);
  }

  const direction = tabOrder.indexOf(activeTab) > tabOrder.indexOf(prevTab) ? 1 : -1;

  const variants = {
    enter: (dir) => ({ x: dir * 60, opacity: 0, position: "absolute" }),
    center: { x: 0, opacity: 1, position: "relative" },
    exit: (dir) => ({ x: dir * -60, opacity: 0, position: "absolute" }),
  };

  function renderPanel() {
    switch (activeTab) {
      case "home":
        return (
          <HomePanel
            book={selectedBook}
            onHighlight={(text) => {
              setHighlightedText(text);
              setOpenChat(true);
            }}
          />
        );
      case "textbook":
        return (
          <TextbookPanel
            onHighlight={(text) => {
              setHighlightedText(text);
              setOpenChat(true);
            }}
            openBook={(book) => {
              setSelectedBook(book);
              setPrevTab(activeTab);
              setActiveTab("home");
            }}
          />
        );
      case "settings":
        return <SettingsPanel />;
      default:
        return null;
    }
  }

  return (
    <div className="h-screen w-screen flex flex-col">
      <Navbar activeTab={activeTab} setActiveTab={switchTab} />
      <div className="relative flex-1 overflow-y-auto bg-gray-50">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={activeTab}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.28, ease: "easeOut" }}
            className="h-full"
          >
            {renderPanel()}
          </motion.div>
        </AnimatePresence>
      </div>
      <ChatWidget
        highlightedText={highlightedText}
        openChat={openChat}
        setOpenChat={setOpenChat}
      />
    </div>
  );
}
